# BetterScroll

BetterScroll for jQuery allows you to easily turn your page with sections into single page scroll.

# Demo

See [live example](http://devbridge.github.io/jQuery-BetterScroll).

##License

BetterScroll for jQuery is freely distributable under the 
terms of an MIT-style [license](https://github.com/devbridge/jQuery-BetterScroll/blob/master/dist/license.txt).

Copyright notice and permission notice shall be included in all 
copies or substantial portions of the Software.
